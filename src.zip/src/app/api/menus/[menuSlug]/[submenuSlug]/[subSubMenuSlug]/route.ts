import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(req: NextRequest, { params }: { params: { menuSlug: string; submenuSlug: string; subSubMenuSlug: string } }) {
  try {
    const { menuSlug, submenuSlug, subSubMenuSlug } = params;

    const parentMenu = await prisma.menu.findFirst({
      where: {
        title: {
          equals: menuSlug.replace(/-/g, ' '),
        },
      },
    });

    if (!parentMenu) {
      return NextResponse.json({ error: 'Parent menu not found' }, { status: 404 });
    }

    const submenu = await prisma.menu.findFirst({
      where: {
        title: {
          equals: submenuSlug.replace(/-/g, ' '),
        },
        parentId: parentMenu.id,
      },
    });

    if (!submenu) {
      return NextResponse.json({ error: 'Submenu not found' }, { status: 404 });
    }

    const subSubMenu = await prisma.menu.findFirst({
      where: {
        title: {
          equals: subSubMenuSlug.replace(/-/g, ' '),
        },
        parentId: submenu.id,
      },
    });

    if (!subSubMenu) {
      return NextResponse.json({ error: 'Sub-submenu not found' }, { status: 404 });
    }

    return NextResponse.json(subSubMenu, { status: 200 });
  } catch (error) {
    console.error('Error fetching sub-submenu:', error);
    return NextResponse.json({ error: 'Failed to fetch sub-submenu' }, { status: 500 });
  }
}
