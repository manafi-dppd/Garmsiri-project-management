const Home = () => {
  return <h2>Hello next.js</h2>;
};

export default Home;
