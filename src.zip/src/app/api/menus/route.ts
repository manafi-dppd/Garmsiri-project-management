import {NextRequest, NextResponse} from 'next/server';
import {PrismaClient} from '@prisma/client';

const prisma = new PrismaClient();

// **GET: دریافت منوها با slug و parentSlug**
export async function GET() {
  try {
    const menus = await prisma.menu.findMany({
      where: {active: true},
      select: {
        id: true,
        title: true,
        title_fa: true,
        parentId: true,
      },
    });

    // ایجاد slug و parentSlug
    const menusWithSlug = menus.map((menu) => ({
      ...menu,
      slug: menu.title.toLowerCase().replace(/\s+/g, '-'),
      parentSlug: menu.parentId
        ? menus
            .find((parent) => parent.id === menu.parentId)
            ?.title.toLowerCase()
            .replace(/\s+/g, '-')
        : null,
    }));

    return NextResponse.json(menusWithSlug);
  } catch (error) {
    console.error('Error fetching menus:', error);
    return NextResponse.json({error: 'Failed to fetch menus'}, {status: 500});
  }
}

// **POST: اضافه کردن یک منو جدید**
export async function POST(req: NextRequest) {
  try {
    const {title, title_fa, active, parentId} = await req.json();

    const newMenu = await prisma.menu.create({
      data: {
        title,
        title_fa,
        active,
        parentId,
      },
    });

    return NextResponse.json(newMenu, {status: 201});
  } catch (error) {
    console.error('Error creating menu:', error);
    return NextResponse.json({error: 'Failed to create menu'}, {status: 500});
  }
}

// **PUT: ویرایش یک منوی موجود**
export async function PUT(req: NextRequest) {
  try {
    const {id, title, title_fa, active, parentId} = await req.json();

    const updatedMenu = await prisma.menu.update({
      where: {id},
      data: {
        title,
        title_fa,
        active,
        parentId,
      },
    });

    return NextResponse.json(updatedMenu, {status: 200});
  } catch (error) {
    console.error('Error updating menu:', error);
    return NextResponse.json({error: 'Failed to update menu'}, {status: 500});
  }
}

// **DELETE: حذف یک منو**
export async function DELETE(req: NextRequest) {
  try {
    const {id} = await req.json();

    const deletedMenu = await prisma.menu.delete({
      where: {id},
    });

    return NextResponse.json(deletedMenu, {status: 200});
  } catch (error) {
    console.error('Error deleting menu:', error);
    return NextResponse.json({error: 'Failed to delete menu'}, {status: 500});
  }
}
