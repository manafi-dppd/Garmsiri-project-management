import { NextResponse } from 'next/server';

export async function GET(
  request: Request,
  { params }: { params: { menuSlug: string[] } }
) {
  try {
    const { menuSlug } = params;

    if (!menuSlug || menuSlug.length === 0) {
      return NextResponse.json({ error: 'menuSlug is required' }, { status: 400 });
    }

    const slugPath = menuSlug.join('/'); // ایجاد مسیر کامل از آرایه
    const menu = await fetchMenuFromDatabase(slugPath);

    if (!menu) {
      return NextResponse.json({ error: 'Menu not found' }, { status: 404 });
    }

    return NextResponse.json(menu);
  } catch (error) {
    console.error('Error fetching menu:', error);
    return NextResponse.json({ error: 'Failed to fetch menu' }, { status: 500 });
  }
}

// تابع شبیه‌سازی شده برای بازیابی منو از پایگاه داده
async function fetchMenuFromDatabase(slugPath: string) {
  // به‌عنوان نمونه می‌توانید این تابع را به داده‌های پایگاه داده متصل کنید
  const menus = {
    'current-affairs/water-request': { id: 1, title: 'Water Request', parent: 'Current Affairs' },
  };
  return menus[slugPath] || null;
}
