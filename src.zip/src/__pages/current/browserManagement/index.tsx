const Home = () => {
  return <h2>مدیریت مرورگر</h2>;
};

export default Home;
