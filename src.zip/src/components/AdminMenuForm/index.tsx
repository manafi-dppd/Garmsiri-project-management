import React, {useState, useEffect} from 'react';

export default function AdminMenuForm() {
  const [mainMenuOptions, setMainMenuOptions] = useState([]);
  const [subMenuOptions, setSubMenuOptions] = useState([]);
  const [subSubMenuOptions, setSubSubMenuOptions] = useState([]);
  const [selectedMainMenu, setSelectedMainMenu] = useState(''); // مقدار پیش‌فرض ""
  const [selectedSubMenu, setSelectedSubMenu] = useState(''); // مقدار پیش‌فرض ""
  const [selectedSubSubMenu, setSelectedSubSubMenu] = useState(''); // مقدار پیش‌فرض ""
  const [activeState, setActiveState] = useState([false, false, false]);
  const [deleteState, setDeleteState] = useState([false, false, false]);
  const [isFormChanged, setIsFormChanged] = useState(false);

  useEffect(() => {
    // دریافت داده‌های منوهای اصلی از API
    fetch('/api/menus')
      .then((res) => res.json())
      .then((data) => {
        const mainMenus = data.filter((menu) => menu.parentId === null);
        setMainMenuOptions(mainMenus);

        // تنظیم مقدار پیش‌فرض چکباکس‌های فعال
        const defaultActiveStates = [
          mainMenus.some((menu) => menu.active) || false,
          false, // برای زیرمنو در ابتدا مقدار ندارد
          false, // برای زیرزیرمنو در ابتدا مقدار ندارد
        ];
        setActiveState(defaultActiveStates);
      })
      .catch((error) => console.error('Failed to fetch menus:', error));
  }, []);

  const handleMainMenuChange = (e) => {
    const selectedId = e.target.value;
    console.log('Selected Main Menu ID:', selectedId);
    setSelectedMainMenu(selectedId);
    setSelectedSubMenu(''); // ریست گزینه زیرمنو
    setSelectedSubSubMenu(''); // ریست گزینه زیرزیرمنو
    setIsFormChanged(true);
    if (selectedId) {
      // دریافت زیرمنوها برای منوی انتخاب‌شده
      fetch(`/api/menus`)
        .then((res) => {
          console.log('API Response:', res);
          return res.json();
        })
        .then((data) => {
          console.log('Fetched Sub Menus:', data);
          const filteredSubMenus = data.filter(
            (menu) => menu.parentId === Number(selectedId),
          );
          setSubMenuOptions(filteredSubMenus);
          setSubSubMenuOptions([]); // ریست زیرزیرمنوها

          // تنظیم مقدار پیش‌فرض چکباکس زیرمنو
          const updatedActiveState = [...activeState];
          updatedActiveState[1] = filteredSubMenus.some((menu) => menu.active);
          setActiveState(updatedActiveState);
        })
        .catch((error) => console.error('Failed to fetch submenus:', error));
    } else {
      setSubMenuOptions([]);
      setSubSubMenuOptions([]);
    }
  };

  const handleSubMenuChange = (e) => {
    const selectedId = e.target.value;
    setSelectedSubMenu(selectedId);
    setSelectedSubSubMenu(''); // ریست گزینه زیرزیرمنو
    setIsFormChanged(true);

    if (selectedId) {
      // دریافت زیرزیرمنوها برای زیرمنوی انتخاب‌شده
      fetch(`/api/menus`)
        .then((res) => res.json())
        .then((data) => {
          const filteredSubSubMenus = data.filter(
            (menu) => menu.parentId === Number(selectedId),
          );
          setSubSubMenuOptions(filteredSubSubMenus);

          // تنظیم مقدار پیش‌فرض چکباکس زیرزیرمنو
          const updatedActiveState = [...activeState];
          updatedActiveState[2] = filteredSubSubMenus.some(
            (menu) => menu.active,
          );
          setActiveState(updatedActiveState);
        })
        .catch((error) => console.error('Failed to fetch subsubmenus:', error));
    } else {
      setSubSubMenuOptions([]);
    }
  };

  const handleSubSubMenuChange = (e) => {
    setSelectedSubSubMenu(e.target.value);
    setIsFormChanged(true);
  };

  const handleActiveChange = (index) => {
    debugger; // اجرای کد را متوقف کرده و وضعیت را بررسی کنید
    const updatedStates = [...activeState];
    updatedStates[index] = !updatedStates[index];
    setActiveState(updatedStates);
  };
  

  const handleDeleteChange = (index) => {
    const updatedStates = [...deleteState];
    updatedStates[index] = !updatedStates[index];
    setDeleteState(updatedStates);
    setIsFormChanged(true);
  };

  const handleSubmit = async () => {
    // ارسال داده‌ها به API
    alert('اطلاعات ارسال شد.');
  };

  return (
    <div>
      <h2>مدیریت منو</h2>
      <table>
        <thead>
          <tr>
            <th>منو</th>
            <th>عنوان</th>
            <th>عنوان انگلیسی</th>
            <th>فعال</th>
            <th>حذف</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>منوی اصلی</td>
            <td>
              <select value={selectedMainMenu} onChange={handleMainMenuChange}>
                <option value="">انتخاب کنید</option>
                {mainMenuOptions.map((menu) => (
                  <option key={menu.id} value={menu.id}>
                    {menu.title_fa}
                  </option>
                ))}
              </select>
            </td>
            <td>
              {(selectedMainMenu &&
                mainMenuOptions.find(
                  (menu) => menu.id === Number(selectedMainMenu),
                )?.title) ||
                ''}
            </td>
            <td>
              <input
                type="checkbox"
                checked={activeState[0]}
                disabled={!selectedMainMenu}
                onChange={() => handleActiveChange(0)}
              />
            </td>
            <td>
              <input
                type="checkbox"
                checked={deleteState[0]}
                disabled={!selectedMainMenu}
                onChange={() => handleDeleteChange(0)}
              />
            </td>
          </tr>
          <tr>
            <td>زیرمنو</td>
            <td>
              <select
                value={selectedSubMenu}
                onChange={handleSubMenuChange}
                disabled={!selectedMainMenu}
              >
                <option value="">انتخاب کنید</option>
                {subMenuOptions.map((menu) => (
                  <option key={menu.id} value={menu.id}>
                    {menu.title_fa}
                  </option>
                ))}
              </select>
            </td>
            <td>
              {(selectedSubMenu &&
                subMenuOptions.find(
                  (menu) => menu.id === Number(selectedSubMenu),
                )?.title) ||
                ''}
            </td>
            <td>
              <input
                type="checkbox"
                checked={activeState[1]}
                disabled={!selectedSubMenu}
                onChange={() => handleActiveChange(1)}
              />
            </td>
            <td>
              <input
                type="checkbox"
                checked={deleteState[1]}
                disabled={!selectedSubMenu}
                onChange={() => handleDeleteChange(1)}
              />
            </td>
          </tr>
          <tr>
            <td>زیرزیرمنو</td>
            <td>
              <select
                value={selectedSubSubMenu}
                onChange={handleSubSubMenuChange}
                disabled={!selectedSubMenu}
              >
                <option value="">انتخاب کنید</option>
                {subSubMenuOptions.map((menu) => (
                  <option key={menu.id} value={menu.id}>
                    {menu.title_fa}
                  </option>
                ))}
              </select>
            </td>
            <td>
              {(selectedSubSubMenu &&
                subSubMenuOptions.find(
                  (menu) => menu.id === Number(selectedSubSubMenu),
                )?.title) ||
                ''}
            </td>
            <td>
              <input
                type="checkbox"
                checked={activeState[2]}
                disabled={!selectedSubSubMenu}
                onChange={() => handleActiveChange(2)}
              />
            </td>
            <td>
              <input
                type="checkbox"
                checked={deleteState[2]}
                disabled={!selectedSubSubMenu}
                onChange={() => handleDeleteChange(2)}
              />
            </td>
          </tr>
        </tbody>
      </table>
      <button onClick={handleSubmit} disabled={!isFormChanged}>
        ارسال
      </button>
    </div>
  );
}
