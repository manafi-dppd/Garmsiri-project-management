'use client';

import {useParams} from 'next/navigation';

export default function Page() {
  const params = useParams();

  return (
    <div>
      <h1>صفحه منوی اصلی</h1>
      <p>شناسه منو: {params.menuSlug}</p>
    </div>
  );
}
